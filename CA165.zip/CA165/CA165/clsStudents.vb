﻿Public Class clsStudents
    Public stid As Integer
    Public lname As String
    Public test_score As Double

    Public Sub save(sid As Integer, ln As String, ts As Double)
        stid = sid
        lname = ln
        test_score = ts
    End Sub

End Class
