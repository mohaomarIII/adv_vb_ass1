﻿Public Class Form1
    Dim std1 As New clsStudents



    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        std1.save(txtStudentID.Text, txtLastName.Text, txtTestScore.Text)
        txtMessage.Text = "information saved successfully."
        cleartxts()

    End Sub
    Sub cleartxts()
        txtStudentID.Clear()
        txtLastName.Clear()
        txtTestScore.Clear()
    End Sub
    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        txtStudentID.Text = std1.stid
        txtLastName.Text = std1.lname
        txtTestScore.Text = std1.test_score
    End Sub
End Class
